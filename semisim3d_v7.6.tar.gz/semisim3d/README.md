# SemiSim 3D

A 3-D drift-diffusion simulator for semiconductor devices, with a desktop
interface for building a device, solving it and looking inside it.

A C core (OpenMP) solves Poisson's equation and the electron and hole
continuity equations with the box method and Scharfetter-Gummel fluxes, on a
graded rectangular mesh or on triangular prisms that follow round and sloped
interfaces. The Python/Tk interface draws the structure, the bands, the
current flow and the I-V curves. 47 device templates are included, from a
p-n diode to FinFETs, a CMOS inverter, SiC and GaN power devices, IGBTs and
thyristors, and the core is checked against closed-form semiconductor theory
(167 checks in `validate.py`).

> **Test version.** SemiSim 3D is still being tested: its results can be
> wrong. Read the [Status](#status-test-version) below before relying on them.

![FinFET with a tapered, rounded fin on the triangular-prism mesh](docs/screenshots/finfet_structure.png)

| | |
|---|---|
| ![Current flow in an n-JFET](docs/screenshots/jfet_current.png) | ![CMOS inverter transfer curve](docs/screenshots/cmos_transfer.png) |
| ![Electron density in a gate-all-around nanowire FET](docs/screenshots/gaa_slicer.png) | ![A diode with a metal particle, a void and a dislocation](docs/screenshots/defects_structure.png) |

## Status: test version

SemiSim 3D is a personal project, and it is still being tested. Please read
its results with that in mind:

- It is not a commercial TCAD tool. The physics is checked against textbook
  theory (`validate.py`, 167 checks), but not yet against measurements of
  real devices.
- Results can be wrong, and some effects are not modelled at all (impact
  ionisation and avalanche breakdown, band-to-band tunnelling, light,
  self-heating, transients - see
  [Limitations](docs/MANUAL.md#limitations)). Check anything important
  against measurements, the literature or an established simulator.
- The `RW:` templates are modelled on the device class and ratings of real
  parts; they are not the real dies, and the currents are per simulated cell.
- macOS support and the WSL2 full-screen workaround are new and have been
  tried on few computers so far.
- Things can change between versions, including the format of saved device
  files.

Problems and suggestions are welcome as GitHub issues: say what you did,
attach the saved device (`File → Save device`), and paste the output of
`python3 semibuild.py --check` and any error message.

## What it does

- **Devices:** diodes, BJTs (vertical, lateral, SOI), MOSFETs, a CMOS
  inverter, FinFETs and a gate-all-around nanowire, JFETs, HEMTs, VDMOS,
  LDMOS, trench MOSFETs, IGBTs, thyristors, solar cells, LEDs, photodiodes -
  in Si, Ge, GaAs, InP, AlGaAs, 4H-SiC, GaN and AlGaN, with SiO2, Al2O3, HfO2 and
  Si3N4 dielectrics. Build your own from material/doping blocks.
- **Physics:** heterojunctions, Klaassen band-gap narrowing, Arora mobility
  with velocity saturation and Lombardi surface mobility, SRH (doping
  dependent), Auger and radiative recombination, quantum confinement (MLDA),
  gate tunnelling (direct and Fowler-Nordheim), metal contacts with real
  barrier heights (thermionic emission, image-force lowering, tunnelling
  through the barrier), GaN polarisation charge.
- **Defects:** voids, oxide and metal particles, metal contamination (Fe, Au,
  Pt, Cu), radiation damage, interface traps, oxide charge, dislocations,
  stacking faults and grain boundaries - placed by hand or scattered at
  random, with deep-level physics (SRH through each level plus the charge it
  traps).
- **Experiments:** bias points, sweeps, nets (contacts wired together),
  floating terminals (transfer curves of logic gates), parameter extraction
  (ideality, V_th, subthreshold swing, I_on/I_off, gain and noise margins).
- **Numerics:** Newton-Poisson with multigrid CG, BiCGSTAB with aggregation
  multigrid for the continuity equations, a Gummel map with Anderson
  acceleration, adaptive bias continuation with a sweep predictor, adaptive
  mesh refinement.

Not modelled: impact ionisation (avalanche breakdown), band-to-band
tunnelling, optical generation, self-heating, transients. See
[Limitations](docs/MANUAL.md#limitations).

## Install

You need a C compiler and Python 3.8 or newer with Tk, NumPy and Matplotlib.
`install.sh` checks all of that, installs what is missing, builds the solver
core for your computer, runs a short self-test and adds a launcher.

### Linux and Windows (WSL2)

On Windows, use WSL2 with Ubuntu (WSLg shows the window on the Windows
desktop). In a Linux / WSL terminal:

```bash
git clone https://github.com/YOUR-USER/semisim3d.git
cd semisim3d
bash install.sh
semisim3d            # (in a new terminal) or: python3 main.py
```

The installer uses your distribution's packages (Ubuntu/Debian, Fedora, Arch,
openSUSE) and asks for your password for them. On WSL2 the program also
appears in the Windows Start menu.

### macOS (Apple silicon or Intel)

1. Install Apple's command line tools (the C compiler):
   `xcode-select --install`
2. Install Python 3.12 or newer from
   [python.org](https://www.python.org/downloads/macos/) (it includes Tk).
   With [Homebrew](https://brew.sh) you can skip this: the installer then uses
   Homebrew's Python. Homebrew also gives the solver all CPU cores (the
   installer adds `libomp`); without it the core runs on one core.
3. In Terminal:

   ```bash
   git clone https://github.com/YOUR-USER/semisim3d.git
   cd semisim3d
   bash install.sh
   ```
   (No git? On the GitHub page use Code → Download ZIP, unpack it, and run
   `bash install.sh` inside the unpacked folder.)
4. Start it with a double click on `SemiSim3D.command` in the folder, or
   `python3 main.py` / `semisim3d` in Terminal.

On a Mac keyboard F5 needs the fn key: ⌘R runs, ⌘. stops, and the other
shortcuts use ⌘ instead of Ctrl.

### By hand

```bash
python3 -m pip install -r requirements.txt   # numpy, matplotlib (Tk comes with Python)
python3 semibuild.py                          # build the core (gcc or clang; OpenMP if available)
python3 main.py
```

`main.py` builds the core by itself on the first start, and again after an
update of `semiconductor_3d.c`. `python3 semibuild.py --check` shows the
compiler and OpenMP in use.

## First steps

1. Pick a device in the `Device ▾` menu of the toolbar. The `Structure` tab
   shows it in 3-D and in cross-section, with the mesh.
2. `▶ Run` (F5) solves it at the voltages in the `Contacts` page; look at the
   `Bands`, `Current` and `Field & Mobility` tabs.
3. `↔ Sweep` (F6) runs the I-V sweep set in the `Sweep` page; the curve grows
   live in the `I-V` tab. `■ Stop` (Esc) keeps the last converged point.
4. Change regions, contacts, defects or the mesh in the editor on the left
   and run again. `File → Save device` keeps the whole setup.

Help (F1) has the full manual, also in [docs/MANUAL.md](docs/MANUAL.md).

## Good to know

- **Full screen:** F11 (View → Fill the screen) makes the window as large as
  the screen and back. On WSL2, WSLg sends the mouse clicks of a *maximised*
  window to the wrong place (the buttons stop responding while the 3-D view
  still turns); SemiSim therefore turns the maximise button into F11 there.
- **Current tab:** the number boxes next to `2-D arrows` and `3-D arrows` set
  how many current arrows are drawn.
- **Speed:** most templates solve in seconds on a laptop; 3-D meshes with
  10⁵-10⁶ nodes take minutes per bias point. The solver uses all cores (on
  Apple silicon the performance cores); Solver page → CPU threads.

## Validation

`python3 validate.py` (about 5 minutes) compares the core with closed-form
theory: built-in potential and depletion width, the Shockley diode, 4H-SiC
blocking fields to 2 kV, heterojunction offsets, the MOS capacitor and
long-channel MOSFET, the BJT Gummel integral, Schottky diodes against
Crowell-Sze theory, contact resistivity against an independent Tsu-Esaki
calculation, gate tunnelling, MLDA and Lombardi against published results,
deep-level compensation and trap-limited lifetimes, interface traps and oxide
charge, the prism mesh against the rectangular one, adaptive mesh refinement
against uniformly refined meshes. `--templates` also solves every template
(167 checks). Details: [docs/MANUAL.md](docs/MANUAL.md#validation).

## Files

| File | |
|---|---|
| `main.py` | the program: interface, device templates, meshing, sweeps |
| `semiconductor_3d.c` | the solver core (C, OpenMP) |
| `semibuild.py` | builds the core (gcc/clang, Linux and macOS) |
| `semimesh.py` | triangular-prism mesher |
| `semidefects.py` | defect library and its mapping onto the mesh |
| `validate.py` | physics validation battery |
| `install.sh` | installer (Linux, WSL2, macOS) |
| `tests/gui_smoke.py` | interface smoke test (used by CI) |
| `docs/MANUAL.md` | user manual |
| `docs/SOURCES.md` | the literature, data and software it is built on |
| `CHANGELOG.md` | version history |

## Sources

The models, the material and defect parameters, the device structures and
the test references all come from published work: textbooks (Sze & Ng,
Selberherr, Taur & Ning, Baliga, Kimoto & Cooper), the papers behind each
model (Scharfetter-Gummel, Arora, Caughey-Thomas, Lombardi, Klaassen,
Shockley-Read-Hall, Crowell-Sze, Tsu-Esaki, MLDA, ...), data compilations
(the Ioffe Institute's NSM archive, Vurgaftman et al.) and the defect
literature. The full list, with every reference, is in
[docs/SOURCES.md](docs/SOURCES.md) and in the program under Help → Sources.

## Use and sharing

SemiSim 3D is free to use, copy, change and share, for any purpose, without
asking. There is no licence and there are no conditions. It comes as it is,
without any warranty: whoever uses it is responsible for how they use its
results.
