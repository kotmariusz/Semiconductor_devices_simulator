# Changelog

## 7.6 (2026-10-07)

**Window size and WSL2**

* F11 (View → Fill the screen / restore) makes the window as large as the
  screen and back; View → Reset window size.
* WSL2: WSLg sends the clicks of a *maximised* window to the wrong place (the
  buttons stopped responding after the maximise button, only the 3-D view
  still turned). A maximise is now turned into the same rectangle as a normal
  window, which WSLg handles correctly (View → `WSL: turn maximise into fill
  screen`, on by default).
* A maximised or filled window is no longer saved as the normal window size.
* The plot handlers that re-place labels and move 3-D views clear of their
  neighbours share one guarded re-draw (at most 6 in a row per plot), so
  they can never keep a plot redrawing.

**Current tab:** number boxes next to `2-D arrows` (4–120 across the map) and
`3-D arrows` (2–40 along x) set how many current arrows are drawn. The
current is interpolated to the arrow points, so the count is no longer tied
to the mesh nodes; denser arrows are drawn shorter and thinner; the 3-D
title gives the arrow count. Both settings are remembered.

**macOS**

* The core is built automatically with Apple's clang; with Homebrew's
  `libomp` it runs on all performance cores (single-threaded without it).
* `install.sh` works on macOS: finds a Python with Tk 8.6+ (python.org or
  Homebrew; installs Homebrew's when there is none), makes a virtual
  environment with NumPy and Matplotlib, adds libomp, builds, self-tests and
  creates `SemiSim3D.command` (double click to start).
* Coloured buttons and check boxes that macOS would draw in its own colours
  (white captions on white buttons) are drawn by the program; matplotlib
  toolbar icons stay visible.
* ⌘ shortcuts (⌘O/⌘S/⌘E/⌘+/⌘−/⌘0, ⌘R run, ⌘. stop), the application menu
  (About, Quit), fonts scaled for macOS's 72-dpi convention, free-memory
  check, App Nap opt-out (a hidden window does not slow a sweep down), the
  performance cores by default on Apple silicon.
* Tk 9 (Homebrew): trackpad scrolling of the editor pages; a clear message
  when Matplotlib is older than 3.10 (needed for Tk 9).

**Build and install**

* `semibuild.py`: finds the compiler and OpenMP (gcc, clang, Apple clang +
  libomp, Homebrew gcc), tunes for the CPU or builds portable, tests every
  combination on a tiny library first, records the source hash.
* `main.py` builds the core on the first start, after an update of
  `semiconductor_3d.c` and when the core was built on another kind of
  computer; start-up problems (no Tk, NumPy, Matplotlib or compiler; Tk 8.5)
  are explained in the terminal and in a window.
* `install.sh` for Ubuntu/Debian/WSL2, Fedora, Arch, openSUSE and macOS; a
  menu entry on Linux (on WSL2 in the Windows Start menu); a window icon.
* The repository no longer carries a prebuilt core: it is built on each
  computer.

**GitHub:** README with screenshots and a status note (a test version, still
being tested), the user manual (`docs/MANUAL.md`), the full list of sources
(`docs/SOURCES.md`; also Help → Sources), a CI workflow (Ubuntu and macOS:
install.sh, validation, GUI smoke test) and `tests/gui_smoke.py`. No licence:
the program is free to use, copy, change and share, without warranty
(README, Help → Status and terms).

**Fixes** (found while checking the parameters against their sources)

* Germanium: the valence-band density of states was 10x too large (6e19
  instead of 6.0e18 cm⁻³), so n_i was 3x and the Ge photodiode's dark current
  about 10x too high. n_i is now 2.2e13 cm⁻³ at 300 K.
* InP: the band gap used its 300 K value as the 0 K value (1.279 eV at
  300 K); now Vurgaftman et al. 2001, 1.353 eV at 300 K. No template uses InP.
* The defect library's note on gold cited a source that could not be
  confirmed; it now names Bullis (1966) and Graff (2000), and the copper
  precipitate note gives the full Seibt et al. (1998) reference.

The validation battery passes with gcc and with clang + libomp (the macOS
combination) alike.

## 7.5

**Contact metals** (Contacts page → `Metal`; Solver page: two switches, on
by default)

* 20 metals and silicides with measured barrier heights on Si, GaAs, 4H-SiC
  and GaN, or the Cowley-Sze pinning model for any other pair.
* Thermionic emission with image-force lowering built into the band
  (screened by the carriers), and tunnelling through the barrier (Tsu-Esaki
  with WKB along each contact column) - the doping decides between ohmic and
  rectifying. Velocity saturation is tapered off across the barrier; the
  reverse current of a barrier, carried by trace electrons, is accepted at
  its noise floor.
* New template `Metal contacts: ohmic vs Schottky (Al)`. The Schottky, 1N5819
  and SiC JBS templates use real metals (W, Mo, Ti); the JBS also got ohmic
  contacts on its p⁺ stripes, which had floated under the Schottky metal.

**Defects** (`semidefects.py`, Defects page)

* 26 library defects in six categories, five shapes, manual placement and
  random scatter (number or density, seed, size spread, groups).
* Core: deep-level species with any number per node (SRH through each level
  + trapped charge in Poisson's Newton step and the continuity matrices),
  fixed volume charge, the Void and Metal (incl.) materials, neutral ohmic
  contacts with trapped charge.
* Exact numbers of states on any mesh (sub-mesh shapes spread over the
  nearest nodes, inclusion surfaces with their true area); inclusions
  smaller than the cells act through their surface states; the Defects page
  reports such cases after a run.
* Solver page: `Background SRH τ0` (material default, a lifetime, or none).
* Structure tab draws defects (filled where cut, dotted otherwise; hover);
  solution maps outline them; 3D Slicer `trap density` and `trapped charge`.
* Templates `Defects: leaky p-n junction (particle, void, dislocation)` and
  `Defects: NMOS after irradiation (oxide charge + D_it)`.

**Faster solving**

* Sweep predictor (secant extrapolation from the previous sweep points, and
  interpolation for the secant steps of a floating terminal): 20–30 % fewer
  Gummel iterations on typical sweeps, the IGBT output curve 2.1× faster.
* Continuation: after a slowly converging step the next one is 2.2× longer
  (was 1.2×): −24 % iterations over the default solves of all templates; the
  GaN RF HEMT 2.2×, the Si trench MOSFET 3.7×, the VDMOS 1.6× faster.

**Adaptive mesh refinement** (Device page; rectangular mesh): refine where
the solution bends within a cell by more than a threshold in kT/q, re-solve
from the interpolated solution, up to a node budget; kept for sweeps and
saved with the device.

**Templates:** `Lateral PNP (bipolar IC)`, `SOI lateral NPN`, the metal and
defect templates above - 47 in all.

**Readable plots**

* Region labels on maps are placed only where they fit, never on top of each
  other or of a contact, and re-placed when the window size changes.
* Line cuts mark the regions they cross in two staggered rows above the
  curves; thin lines mark every boundary.
* A 3-D view whose perspective box or labels run into a neighbouring plot is
  moved clear of it; a thin 3-D axis gets two ticks instead of a pile.
* The semi-log I-V panel spans the currents that matter; legends list
  contact metals and defects.

**Fixes**

* Mesh: the second node of every pinned interface pair was dropped (the axis
  array was no longer sorted after the first insertion), so some oxide and
  electrode faces were 0.5 nm off. Effect on the templates: Si trench MOS
  +0.9 %, SiC trench MOS +0.2 %, FinFET and 1200 V IGBT unchanged.

**Validation:** section 14 (metal contacts), 15 (defects) and 16 (adaptive
mesh refinement, sweep predictor).

## 7.4

**Triangular (prism) mesh** - a mesh switch on the Device page.

* `semimesh.py`: Delaunay triangulation of the cross-section extruded along
  a prism axis; box geometry keeps the rectangular mesh's nodes near every
  feature and thins them elsewhere; outlines get normal rows with node pairs
  straddling each interface, boundary layers and aligned gate-stack layers.
* **Outlines (shapes)** for regions and box contacts: rounded convex
  polygons and circles, offset families for conformal films, gate electrodes
  wrapped round them. On the rectangular mesh they become staircases.
* **Core:** general box-method graphs (CSR) next to the tensor path, with
  their own aggregation multigrid, least-squares node gradients,
  host-supplied interface walls, node-list contacts and tunnelling paths
  along aligned edges.
* **GUI:** the Structure tab draws outlines and the triangles; the 3D Slicer
  draws prism cross-sections on the triangulation; Save/Open keeps outlines
  and the mesh choice; the solution CSV exports the prism nodes.

**Templates:** `FinFET (tapered, rounded fin)` and `GAA nanowire FET
(round)`. **Validation:** section 13.

## 7.3

* **Gate tunnelling** (direct and Fowler-Nordheim, electrons and holes,
  through any gate stack), **high-k materials** (HfO2, Si3N4) and gate
  stacks on face gates, **quantum confinement (MLDA)** and **Lombardi
  surface mobility**; templates carry their model switches.
* FinFET rebuilt with a 0.5 nm SiO2 + 2.5 nm HfO2 stack; new category "Gate
  dielectrics & tunnelling".
* A continuity solve that diverges after the ILU retry fails the step
  instead of being used; pinned interface nodes replace graded nodes closer
  than 0.05 nm. **Validation:** sections 11 and 12.

## 7.2

* Rebuilt interface: toolbar and a hideable, resizable editor drawer; pages
  that scroll both ways; text size; template browser; XY/YZ/XZ structure
  sections with the real mesh; background jobs with progress and Stop; a
  Results tab; scrollable Help; Save/Open device and sweep CSV.
* Nets and floating terminals (transfer curves with adaptive refinement);
  CMOS Inverter and FinFET templates. **Validation:** section 10.

## 7.1

* Anderson mixing on (ψ, φₙ, φₚ) (HEMT, NMOS and VDMOS solves 2–5× faster),
  double-precision face mobilities, a floating-region balance step, exact
  quasi-Fermi clamping, noise-floor acceptance, gates ramped first, each
  terminal reporting its better-resolved current.
* Redesigned IGBT, SiC trench MOSFET, n-JFET, GaN e-mode HEMT, HBT and
  thyristor templates; oxide and buried-electrode faces pinned on both sides.
